UPDATED NFC DIGITAL BUSINESS CARD FILES

Upload these three files to the root of your GitHub Pages repository (replace the old ones):
- index.html
- profile.jpg  (new profile photo)
- james-gabas.vcf

Changes:
- Name: Engr. James Tiongson Gabas
- Title: Electrical Engineer
- New highlighted profile photo
- QR code section removed (qrcode.png is no longer needed)

The NFC tag does not need to be changed; the link stays https://j79206495-afk.github.io/
